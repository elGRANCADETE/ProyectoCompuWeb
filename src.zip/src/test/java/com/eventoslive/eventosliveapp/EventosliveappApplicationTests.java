package com.eventoslive.eventosliveapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventosliveappApplicationTests {

	@Test
	void contextLoads() {
	}

}
