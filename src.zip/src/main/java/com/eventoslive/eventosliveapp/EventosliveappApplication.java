package com.eventoslive.eventosliveapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosliveappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventosliveappApplication.class, args);
	}

}
