package com.eventoslive.eventosliveapp.exceptions;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
    
    // Aquí puedes agregar más lógica o constructores si lo necesitas
}