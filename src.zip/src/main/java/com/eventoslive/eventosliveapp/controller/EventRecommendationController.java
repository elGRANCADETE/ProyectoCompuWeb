package com.eventoslive.eventosliveapp.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eventoslive.eventosliveapp.model.EventRecommendation;
import com.eventoslive.eventosliveapp.service.EventRecommendationService;

@RestController
@RequestMapping("/recommendations")
public class EventRecommendationController {

    private final EventRecommendationService eventRecommendationService;

    public EventRecommendationController(EventRecommendationService eventRecommendationService) {
        this.eventRecommendationService = eventRecommendationService;
    }

    @PostMapping("/recommend")
    public ResponseEntity<EventRecommendation> recommendEvent(
        @RequestParam(name = "eventId") Long eventId,
        @RequestParam(name = "senderId") Long senderId,
        @RequestParam(name = "recipientId") Long recipientId) {
        
        if (eventId == null || senderId == null || recipientId == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        EventRecommendation newRecommendation = eventRecommendationService.recommendEvent(eventId, senderId, recipientId);
        return ResponseEntity.status(HttpStatus.CREATED).body(newRecommendation);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<EventRecommendation>> getRecommendations(@PathVariable Long userId) {
        List<EventRecommendation> recommendations = eventRecommendationService.getRecommendationsForUser(userId);
        return ResponseEntity.ok(recommendations);
    }

    @PostMapping("/create")
    public ResponseEntity<EventRecommendation> createRecommendation(@RequestBody EventRecommendation recommendation) {
        EventRecommendation newRecommendation = eventRecommendationService.createRecommendation(recommendation);
        return ResponseEntity.ok(newRecommendation);
    }
}
