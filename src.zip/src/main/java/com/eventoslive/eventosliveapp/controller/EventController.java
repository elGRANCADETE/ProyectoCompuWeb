package com.eventoslive.eventosliveapp.controller;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.eventoslive.eventosliveapp.model.Event;
import com.eventoslive.eventosliveapp.model.EventDTO;
import com.eventoslive.eventosliveapp.service.EventService;

@RestController
@RequestMapping("/events")
public class EventController {
    
    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }
/* 
    @GetMapping("/all")
    public ResponseEntity<List<Event>> getAllEvents() {
        List<Event> events = eventService.getAllEvents();
        return ResponseEntity.ok(events);
    }
*/
    @PutMapping("/{eventId}")
    public ResponseEntity<Event> updateEvent(@PathVariable Long eventId, 
                                             @ModelAttribute Event event, 
                                             @RequestParam("eventCover") MultipartFile eventCover) {
        Event updatedEvent = eventService.updateEvent(eventId, event, eventCover);
        return ResponseEntity.ok(updatedEvent);
    }
    

    @DeleteMapping("/{eventId}")
    public ResponseEntity<?> deleteEvent(@PathVariable Long eventId) {
        eventService.deleteEvent(eventId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('ORGANIZER')")
    public ResponseEntity<Event> createEvent(@ModelAttribute Event event, 
                                             @RequestParam("eventCover") MultipartFile eventCover, 
                                             Principal principal) {

        String username = principal.getName(); // Obtiene el nombre de usuario del usuario autenticado
        Event newEvent = eventService.createEvent(event, username, eventCover);
        return ResponseEntity.status(HttpStatus.CREATED).body(newEvent);
    }

    @GetMapping("/details/{eventId}")
    public String showEventDetails(@PathVariable Long eventId, Model model) {
        Event event = eventService.getEventById(eventId);
        model.addAttribute("event", event);
        return "event-details";
    }
    
    @GetMapping("/list")
    public String showAllEvents(Model model) {
        List<Event> events = eventService.getAllEvents();
        Long totalNumberOfEvents = eventService.getTotalNumberOfEvents(); // Obtener el número total de eventos
        model.addAttribute("events", events);
        model.addAttribute("totalNumberOfEvents", totalNumberOfEvents); // Agregar al modelo
        return "events"; // Nombre del archivo HTML en la carpeta templates
    }
    /* 
    @GetMapping("/saved-events")
    public String getSavedEvents(Model model, Authentication authentication) {
        String username = authentication.getName(); // Obtiene el nombre de usuario autenticado
        List<Event> savedEvents = eventService.findSavedEventsByUsername(username); // Suponiendo que tienes este método
        model.addAttribute("savedEvents", savedEvents);
        return "saved-events";
    }
    */


    @GetMapping("/user/home/savedEvents")
public String showSavedEvents(Model model, Principal principal) {
    String username = principal.getName();
    List<Event> savedEvents = eventService.findSavedEventsByUsername(username);
    model.addAttribute("savedEvents", savedEvents);
    return "/savedEvents";  // Asegúrate de que el nombre del archivo HTML coincide
}

// En tu EventController
@PostMapping("/save/{eventId}")
public ResponseEntity<?> saveEvent(@PathVariable Long eventId, Principal principal) {
    try {
        // Lógica para guardar el evento, usando eventId y username obtenido de principal.getName()
        return ResponseEntity.ok().build();  // Retorna alguna respuesta adecuada
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al guardar el evento: " + e.getMessage());
    }
}


private static final Logger log = LoggerFactory.getLogger(EventController.class);

// En tu controlador
public ResponseEntity<List<EventDTO>> getAllEvents() {
    List<Event> events = eventService.getAllEvents();
    List<EventDTO> eventDTOs = events.stream()
                                     .map(this::convertToDTO)
                                     .collect(Collectors.toList());
    return ResponseEntity.ok(eventDTOs);
}

private EventDTO convertToDTO(Event event) {
    EventDTO dto = new EventDTO();
    dto.setId(event.getId());
    dto.setTitle(event.getTitle());
    dto.setDescription(event.getDescription());
    // setear otros campos
    return dto;
}

}

