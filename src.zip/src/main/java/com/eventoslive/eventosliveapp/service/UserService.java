package com.eventoslive.eventosliveapp.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eventoslive.eventosliveapp.exceptions.CustomException;
import com.eventoslive.eventosliveapp.model.User;
import com.eventoslive.eventosliveapp.repository.UserRepository;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public User createUser(User user) {
        // Verificar si el username ya está en uso
        userRepository.findByUsername(user.getUsername()).ifPresent(u -> {
            throw new CustomException("Username ya está en uso");
        });
    
        // Verificar si el email ya está en uso
        userRepository.findByEmail(user.getEmail()).ifPresent(u -> {
            throw new CustomException("Email ya está en uso");
        });
    
        // Establecer el rol por defecto y encriptar la contraseña
        user.setRole("USER");
        user.setPassword(passwordEncoder.encode(user.getPassword()));
    
        // Generar y asignar el token de verificación
        String token = UUID.randomUUID().toString();
        user.setVerificationToken(token);
        user.setVerified(false); // Inicialmente, el usuario no está verificado
        user.setActive(true);
        sendVerificationEmail(user, token); // Envía el correo electrónico
    
        return userRepository.save(user); // Guardar el usuario
    }
    

    
    @Transactional
    public User changeUserRole(Long userId, String newRole) {
        if (userId == null) {
            throw new IllegalArgumentException("El ID del usuario no puede ser nulo.");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found")); // Cambia RuntimeException por tu excepción
                                                                            // personalizada
        user.setRole(newRole);
        return userRepository.save(user);
    }
    @Transactional
    public void verifyUser(String token) {
        User user = userRepository.findByVerificationToken(token)
            .orElseThrow(() -> new CustomException("Token de verificación inválido"));
    
        if (user.isVerified()) {
            throw new CustomException("El usuario ya ha sido verificado");
        }
    
        user.setVerified(true);
        userRepository.save(user);
    }

    private void sendVerificationEmail(User user, String token) {
        String apiKey = "TU_API_KEY_SENDGRID";
        Email from = new Email("tucorreo@example.com");
        String subject = "Verifica tu correo electrónico";
        Email to = new Email(user.getEmail());
        String verificationUrl = "http://tu-dominio.com/verify?token=" + token;
        Content content = new Content("text/plain",
                "Haz clic en el siguiente enlace para verificar tu correo electrónico: " + verificationUrl);
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid(apiKey);
        Request request = new Request();
        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            sg.api(request);
        } catch (IOException ex) {
            // Maneja la excepción
        }
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username)
                             .orElseThrow(() -> new CustomException("Usuario no encontrado con username: " + username));
    }
    

    public boolean isUsernameAvailable(String username) {
        return userRepository.findByUsername(username) == null;
    }

    public boolean isEmailAvailable(String email) {
        return userRepository.findByEmail(email) == null;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
/* 
    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));
    }
*/

public Optional<User> findById(Long id) {
    return userRepository.findById(id);
}

    @Transactional
public User updateUser(Long userId, User updatedUser) {
    User user = findById(userId)
    .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + userId)); // Manejo del Optional


    // Actualizar campos del usuario
    user.setUsername(updatedUser.getUsername());
    user.setEmail(updatedUser.getEmail());
    // Actualizar otros campos según sea necesario...

    return userRepository.save(user); // Guardar el usuario actualizado
}



@Transactional
public void updateUser(User user) {
    User existingUser = userRepository.findById(user.getId())
        .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado con ID: " + user.getId()));
    
    // Actualiza los campos del usuario
    existingUser.setUsername(user.getUsername());
    existingUser.setEmail(user.getEmail());
    existingUser.setRole(user.getRole());
    existingUser.setActive(user.isActive());  // Asegúrate de que el modelo User tiene un campo 'active'

    userRepository.save(existingUser);
}

public List<User> findAllUsers() {
    return userRepository.findAll();
}

    
    // Otros métodos del servicio...
}